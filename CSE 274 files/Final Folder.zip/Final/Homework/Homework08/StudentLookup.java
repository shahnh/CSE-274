/**
 * Your implementation of the LookupInterface.  The only public methods
 * in this class should be the ones that implement the interface.  You
 * should write as many other private methods as needed.  Of course, you
 * should also have a public constructor.
 * 
 * @author // TODO: Add your name here
 */
  
 
public class StudentLookup implements LookupInterface {
	
	public StudentLookup() {
		
	}

	@Override
	public void addString(int amount, String s) {
		
	}

	@Override
	public int lookupCount(String s) {
		return 0;
	}

	@Override
	public String lookupPopularity(int n) {
		return null;
	}

	@Override
	public int numEntries() {
		return 0;
	}
    
}
