
public class BinarySearchTree {


	/**
	 * Adds a new string to this BST.
	 * 
	 * @param s The string to be added as a new entry.
	 * @return string added to the BST.
	 */
	public String add(String s) {
		
		return null;
	}


	/**
	 * Tests whether this BST contains a given string.
	 * 
	 * @param s The string to locate.
	 * @return True if the BST contains s, or false if not.
	 */
	public boolean contains(String s) {

				return false;
	}

	/**
	 * Removes a given string from this BST.
	 * 
	 * @param s   The s to be removed.
	 * @return True if the removal was successful, or false if not.
	 */
	public boolean remove(String s) {

				
		return false;
	}

	// 
	/**
	 * Removes the largest node in the given tree,
	 * which will be the rightmost node, and returns
	 * the value from that node. The largest node
	 * will always have 0 or 1 children (if it had
	 * 2 children, then the right node would be larger).
	 * @param n the root of a given tree / subtree 
	 * @return the largest node of the given BST
	 */
	private String removeLargestFromLeftSubtree(Node n) {

		return null;
	}

	/**
	 * Prints the values in order
	 */
	public void inorderTraversal() {
	}


}
